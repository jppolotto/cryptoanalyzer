"""
API keys for cryptocurrency data sources
"""

# CoinMarketCap API key
CMC_API_KEY = "c5aac8a5-6ce5-4564-98bd-acc93dc1fa38"

# CryptoDataDownload API key
CDD_API_KEY = "73f3a088f60e547e8d803f2773d82f7218e83030"
